var base = require('kiosk/add-discount');

Vue.component('spark-kiosk-add-discount', {
    mixins: [base]
});
