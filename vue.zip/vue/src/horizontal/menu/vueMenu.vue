<template>
    <ul class="vuemenu navigation Menu -horizontal">
        <slot></slot>
    </ul>
</template>
<style scoped>
ul.vuemenu {
    height: auto;
}
</style>
