<template>
<div>
    <!--main content-->
    <div class="row">
        <div class="col-md-8 timeline_card">
            <card title="<i class='fa fa-fw ti-time'></i> Timeline">
                <!--timeline-->
                <div>
                    <ul class="timeline">
                        <li>
                            <div class="timeline-badge primary wow bounceInDown center">
                                <i class="fa fa-fw ti-server"></i>
                            </div>
                            <div class="timeline-panel wow bounceInDown" style="display:inline-block;">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">We are a MNC now</h4>
                                    <p>
                                        <small class="text-primary">11 hours ago via Twitter</small>
                                    </p>
                                </div>
                                <div class="timeline-body">
                                    <p>
                                        Lorem Ipsum is simply dummy, vidis lio, quem amistosis quis leo..
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-badge danger wow lightSpeedIn center">
                                <i class="fa fa-fw ti-check-box"></i>
                            </div>
                            <div class="timeline-panel wow slideInRight">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">We won best website award</h4>
                                    <p>
                                        <small class="text-danger">May 08, 2016</small>
                                    </p>
                                </div>
                                <div class="timeline-body">
                                    <p>Lorem Ipsum is simply dummy, vidis litro abertis.</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="timeline-badge info wow lightSpeedIn center">
                                <i class="fa fa-fw ti-credit-card"></i>
                            </div>
                            <div class="timeline-panel wow slideInLeft">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">Hired our first employee</h4>
                                    <p>
                                        <small class="text-info">June 10, 2005</small>
                                    </p>
                                </div>
                                <div class="timeline-body">
                                    <p>
                                        Lorem Ipsum is simply dummy, vidis litro abertis. Pra uium u num
                                        gostis.
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-badge warning wow lightSpeedIn center">
                                <i class="fa fa-fw ti-map"></i>
                            </div>
                            <div class="timeline-panel wow lightSpeedIn">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">Rented an office space</h4>
                                    <p>
                                        <small class="text-warning">Jan 05, 2002</small>
                                    </p>
                                </div>
                                <div class="timeline-body">
                                    <p>
                                        Lorem Ipsum is simply dummy, vidis litro abertis. Cais bolis eu num
                                        gostis.
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="timeline-badge default wow bounceInUp center">
                                <i class="fa fa-fw ti-thumb-up"></i>
                            </div>
                            <div class="timeline-panel wow bounceInUp">
                                <div class="timeline-heading">
                                    <h4 class="timeline-title">Planning to open an office</h4>
                                    <p>
                                        <small class="text-default-gray">jan 02, 2017</small>
                                    </p>
                                </div>
                                <div class="timeline-body">
                                    <p>
                                        Lorem Ipsum is simply dummy, vidis litro abertis. depois divoltis.
                                    </p>
                                    <hr>
                                    <b-dd class="btn" variant="primary" >
                                        <template slot="button-content" ><i class="ti-settings"></i>
                                        </template>
                                        <b-dropdown-item class="content-header">
                                            Action
                                        </b-dropdown-item>
                                        <b-dropdown-item class="content-header">
                                            Another Action
                                        </b-dropdown-item>
                                        <b-dropdown-divider></b-dropdown-divider>
                                        <b-dropdown-item class="content-header">
                                            Separated link
                                        </b-dropdown-item>
                                    </b-dd>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <!--timeline ends-->
            </card>
        </div>
        <div class="col-md-4">
            <div class="row">
                <div class="col-sm-6 col-md-12">
                    <card title="<i class='fa fa-fw ti-comment-alt'></i> Recent Activities">
                        <ul class="schedule-cont">
                            <li class="item success">
                                <div class="data">
                                    <div class="time text-muted"> Just now</div>
                                    <p><span class="text-info">Jade</span> Project team has successfully
                                        completed their
                                        first phase.</p>
                                </div>
                            </li>
                            <li class="item danger">
                                <div class="data">
                                    <div class="time text-muted"> 7min ago</div>
                                    <p>Tinder Project's <span class="text-info">Second</span> review has
                                        completed.</p>
                                </div>
                            </li>
                            <li class="item">
                                <div class="data">
                                    <div class="time text-muted">5hours ago</div>
                                    <p>Richard McClintock, updated his project over view report.</p>
                                </div>
                            </li>
                            <li class="item success">
                                <div class="data">
                                    <div class="time text-muted"> Yesterday</div>
                                    <p>Variations Project <span class="text-info">Evaluation</span> is going
                                        on to highlight
                                        the project success .</p>
                                </div>
                            </li>
                        </ul>
                    </card>
                </div>
                <div class="col-sm-6 col-md-12">
                    <card title=" <i class='fa fa-fw ti-reload'></i> Auto Update">
                        <div>
                            <ul class="timeline-update">
                                <li>
                                    <div class="timeline-badge center">
                                        <img :src='require("../../assets/img/authors/avatar1.jpg")' height="36" width="36"
                                             class="rounded-circle float-right" alt="avatar-image">
                                    </div>
                                    <div class="timeline-panel"
                                         style="display:inline-block;">
                                        <div class="timeline-heading">
                                            <h4 class="timeline-title">Jade Project's Status </h4>
                                            <p>
                                                <small class="text-default-gray">11 hours ago</small>
                                            </p>
                                        </div>
                                        <div class="timeline-body">
                                            <p>
                                                Jade Project team has completed their first phase.
                                            </p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="timeline-badge center">
                                        <img :src='require("../../assets/img/authors/avatar.jpg")' height="36" width="36"
                                             class="rounded-circle float-right" alt="avatar-image">
                                    </div>
                                    <div class="timeline-panel">
                                        <div class="timeline-heading">
                                            <h4 class="timeline-title">Tinder Project</h4>
                                            <p>
                                                <small class="text-default-gray">Sept 10, 2016</small>
                                            </p>
                                        </div>
                                        <div class="timeline-body">
                                            <p>
                                                Tinder Project's Final review has completed.
                                            </p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="timeline-badge center">
                                        <img :src='require("../../assets/img/authors/avatar2.jpg")' height="36" width="36"
                                             class="rounded-circle float-right" alt="avatar-image">
                                    </div>
                                    <div class="timeline-panel">
                                        <div class="timeline-heading">
                                            <h4 class="timeline-title">A new branch in Virginia.</h4>
                                            <p>
                                                <small class="text-default-gray">Jan 02, 2017</small>
                                            </p>
                                        </div>
                                        <div class="timeline-body">
                                            <p>
                                                Planning to have a branch in virginia in the coming year.
                                            </p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="timeline-badge center">
                                        <img :src='require("../../assets/img/authors/avatar3.jpg")' height="36" width="36"
                                             class="rounded-circle float-right" alt="avatar-image">
                                    </div>
                                    <div class="timeline-panel"
                                         style="display:inline-block;">
                                        <div class="timeline-heading">
                                            <h4 class="timeline-title">Daily Status </h4>
                                            <p>
                                                <small class="text-default-gray">2days ago</small>
                                            </p>
                                        </div>
                                        <div class="timeline-body">
                                            <p>
                                                Manager schedules to keep a daily project status track.
                                            </p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="timeline-badge center">
                                        <img :src='require("../../assets/img/authors/avatar4.jpg")' height="36" width="36"
                                             class="rounded-circle float-right" alt="avatar-image">
                                    </div>
                                    <div class="timeline-panel">
                                        <div class="timeline-heading">
                                            <h4 class="timeline-title">Performance report</h4>
                                            <p>
                                                <small class="text-default-gray">Aug 10, 2016</small>
                                            </p>
                                        </div>
                                        <div class="timeline-body">
                                            <p>
                                                Richard, updated his Team over view Performance report.
                                            </p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="timeline-badge center">
                                        <img :src='require("../../assets/img/authors/avatar2.jpg")' height="36" width="36"
                                             class="rounded-circle float-right" alt="avatar-image">
                                    </div>
                                    <div class="timeline-panel">
                                        <div class="timeline-heading">
                                            <h4 class="timeline-title">Project Evaluation</h4>
                                            <p>
                                                <small class="text-default-gray">Oct 05, 2016</small>
                                            </p>
                                        </div>
                                        <div class="timeline-body">
                                            <p>
                                                Variations Project Evaluation is going on to highlight
                                                project.
                                            </p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </card>
                </div>
            </div>
        </div>
    </div>
    <!--main content ends-->
</div>
</template>
<script>
    import card from "./card/card.vue"
require('imports-loader?this=>window!wowjs/dist/wow.min.js');
import newsticker from "jquery-advanced-news-ticker/assets/js/jquery.newsTicker.js"
import animate_css from "animate.css/animate.min.css"
export default {
    name: "timeline",
    components:{
        card
    },
    mounted: function() {
        "use strict";
        $(document).ready(function() {
            new WOW().init();
            //auto timeline update panel

            if ($('.timeline-update').length > 0) {
                $('.timeline-update').newsTicker({
                    row_height: 120,
                    max_rows: 3,
                    speed: 2000,
                    direction: 'up',
                    duration: 3500,
                    autostart: 1,
                    pauseOnHover: 1
                });
            }

            //auto timeline update panel ends
        });
    },
    destroyed: function() {

    }
}
</script>
<style src="../../assets/css/timeline.css"></style>
