<template>
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto col-sm-8 col-sm-offset-2">
                <div class="text-center">
                    <div class="error_img">
                        <img :src='require("../../assets/img/pages/404.gif")' alt="404 error image">
                    </div>
                    <hr class="seperator">
                    <a href="/" class="btn btn-primary link-home">Go Home</a>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    name: "err404",
    mounted: function() {
    },
    destroyed: function() {

    }
}
</script>
<style src="../../assets/css/404.css"></style>
